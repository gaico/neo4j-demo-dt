package nl.stoltenborgh.neo4j.demo.it;

import au.com.bytecode.opencsv.CSVReader;
import nl.stoltenborgh.neo4j.demo.NeoDemoConfig;
import nl.stoltenborgh.neo4j.demo.datacreation.ApiPerson;
import nl.stoltenborgh.neo4j.demo.datacreation.DataCreator;
import nl.stoltenborgh.neo4j.demo.domain.graph.Article;
import nl.stoltenborgh.neo4j.demo.domain.graph.ContentItem;
import nl.stoltenborgh.neo4j.demo.domain.graph.Group;
import nl.stoltenborgh.neo4j.demo.domain.graph.KeyRing;
import nl.stoltenborgh.neo4j.demo.domain.graph.KeyRingKey;
import nl.stoltenborgh.neo4j.demo.domain.graph.Person;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.ArticleRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.ContentItemRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.GroupRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.GroupRepositoryCustomImpl;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.KeyRingKeyRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.KeyRingRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.PersonRepository;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { NeoDemoConfig.class })
public class ITDataCreationTest {

    @Autowired
    DataCreator dataCreator;

    @Autowired
    GroupRepositoryCustomImpl groupRepositoryCustom;

    @Autowired
    GroupRepository groupRepository;

    @Autowired
    ArticleRepository articleRepository;

    @Autowired
    ContentItemRepository contentItemRepository;

    @Autowired
    PersonRepository personRepository;

    @Autowired
    KeyRingRepository keyRingRepository;

    @Autowired
    KeyRingKeyRepository keyRingKeyRepository;



    @Test
    public void createAllData() throws IOException {
        List<ContentItem> contentItems = dataCreator.createContentItems(1000, false);
        List<Article> articles = dataCreator.createArticles(getArticles().subList(0,100), contentItems, 5, false);
        List<Article> combiArticles = dataCreator.createCombiArticles( getArticles().subList(11,13), articles, 3, false);
        //match (ca:Article{malmbergNummer: 592095}) -[]- (a:Article) -[]- (c:ContentItem) return ca, a, c

        List<Group> schools = dataCreator.createSchools(getBoSchools().subList(1, 10), articles, 10, combiArticles, 2, false);
        //MATCH (g:Group {name: "Openbare Basisschool De Esdoorn"}) -[]- (a:Article) -[]- (c:ContentItem) return g, a, c

        List<Person> persons = dataCreator.createStudents(createRandomPersons(1), schools, articles, 7, combiArticles, 1, true);

        Optional<Person> loadedPerson = personRepository.findById(persons.get(0).getId());
        /*
        MATCH (krk:KeyRingKey {value: "fbdcb394-0d6c-44d5-9bbe-03ec5185c6be"}) -[]- (kr:KeyRing) -[]- (p:Person) -[]- (g:Group) -[]- (ag:Article) -[]- (agc:ContentItem)
        MATCH (krk:KeyRingKey {value: "fbdcb394-0d6c-44d5-9bbe-03ec5185c6be"}) -[]- (kr:KeyRing) -[]- (p:Person) -[]- (a:Article) -[]- (ac:ContentItem)
        return krk, kr, p, g, ag, a, agc, ac
        */

        articleRepository.deleteAll();
        contentItemRepository.deleteAll();
        groupRepository.deleteAll();
        personRepository.deleteAll();
        keyRingRepository.deleteAll();
        keyRingKeyRepository.deleteAll();
    }

    @Test
    public void deleteAll(){
        articleRepository.deleteAll();
        contentItemRepository.deleteAll();
        groupRepository.deleteAll();
    }

    @Test
    public void createContentItems() {
        List<ContentItem> contentItems = dataCreator.createContentItems(1000, true);
        assertEquals(getSizeOf(contentItemRepository.findAll()), contentItems.size());
        contentItemRepository.deleteAll();
        assertEquals(getSizeOf(contentItemRepository.findAll()), 0);
    }

    private int getSizeOf(Iterable iterable) {
        if(iterable instanceof List){
            return ((List) iterable).size();
        }
        throw new IllegalArgumentException(iterable.getClass().getName() + " not supported");
    }


    private List<Group> getBoSchools() throws IOException {
        List<List<String>> schoolLines = readCsv("03-alle-vestigingen-bo.csv", ';');
        List<Group> out = new ArrayList<>();
        for(List<String> line: schoolLines){
            out.add(new Group(Group.GroupType.BO, line.get(4)));
        }
        return out;
    }

    @Test
    public void testCreatePersons(){
        List<Person> people = createRandomPersons(5);
        assertEquals(5, people.size());

    }




    private List<Article> getArticles() throws IOException {
        List<List<String>> expectedItemsFile = readCsv("catalogus.2019.Schoolboekhandel.csv", ',');

        List<Article> articles = new ArrayList<>();
        for(List<String> line: expectedItemsFile){
            if(StringUtils.isNotBlank(line.get(0))){
                articles.add(new Article(Integer.valueOf(line.get(0)), line.get(1), line.get(2), new HashSet<>(), new HashSet<>()));
            }
        }
        return articles;
    }

    private List<List<String>> readCsv(String fileName, char seperator) throws IOException {
        String sourceDir = "./src/test/resources/data/";

        List<List<String>> records = new ArrayList<List<String>>();
        try (CSVReader csvReader = new CSVReader(new FileReader(sourceDir + fileName), seperator);) {
            String[] values = null;
            while ((values = csvReader.readNext()) != null) {
                records.add(Arrays.asList(values));
            }
        }
        return records;
    }

    public List<Person> createRandomPersons(int numberOfPersons){
        List<Person> out = new ArrayList<>(numberOfPersons);

        for(int i=0; i< numberOfPersons; i++){
            Person person = generateRandomPerson();
            person.keyRing = generateKeyRingWithKeys();
            out.add(person);
        }
        return out;
    }

    private KeyRing generateKeyRingWithKeys() {
        return new KeyRing(UUID.randomUUID().toString(),
                new KeyRingKey(KeyRingKey.KeyType.REALID, UUID.randomUUID().toString()),
                new KeyRingKey(KeyRingKey.KeyType.ECKID, UUID.randomUUID().toString()));
    }

    private Person generateRandomPerson(){
        RestTemplate restTemplate = new RestTemplate();
        ApiPerson apiPerson = restTemplate.getForObject("https://uinames.com/api/?region=netherlands&amount=1&ext", ApiPerson.class);
        return new Person(apiPerson.getName(), apiPerson.getSurname(), LocalDate.now().minusYears(apiPerson.getAge()));
    }


}
