package nl.stoltenborgh.neo4j.demo;

import nl.stoltenborgh.neo4j.demo.datacreation.DataCreator;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.ArticleRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.PersonRepository;
import org.neo4j.driver.v1.AuthTokens;
import org.neo4j.driver.v1.Driver;
import org.neo4j.driver.v1.GraphDatabase;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;
import org.springframework.data.neo4j.transaction.Neo4jTransactionManager;

@Configuration
@ComponentScan("nl.stoltenborgh.neo4j.demo.domain.graph")
@EnableNeo4jRepositories(basePackages = "nl.stoltenborgh.neo4j.demo.domain.graph.repository")
public class NeoDemoConfig {

    private static final String URI = "bolt://localhost:7687";
    private static final String USER = "neo4j";
    private static final String PASSWORD = "password";

    @Bean
    public org.neo4j.ogm.config.Configuration getConfiguration() {
        return new org.neo4j.ogm.config.Configuration.Builder().uri(URI).credentials(USER, PASSWORD).build();
    }

    @Bean(name = "sessionFactory")
    public SessionFactory getSessionFactory() {
        return new SessionFactory(getConfiguration(),"nl.stoltenborgh.neo4j.demo.domain.graph");
    }

    @Bean(name = "transactionManager")
    public Neo4jTransactionManager getTransactionManager() {
        return new Neo4jTransactionManager(getSessionFactory());
    }

//    @Bean
//    public Driver getNeo4jDriver(){
//        return GraphDatabase.driver( URI, AuthTokens.basic( USER, PASSWORD ) );
//    }
//
//    @Bean
//    public ArticleRepository getArticleRepository(){
//        return new ArticleRepository(getNeo4jDriver());
//    }

    @Bean
    public DataCreator getDataCreator(){
        return new DataCreator();
    }




}
