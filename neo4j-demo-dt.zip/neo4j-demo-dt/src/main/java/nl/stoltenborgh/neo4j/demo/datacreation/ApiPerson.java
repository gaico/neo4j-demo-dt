package nl.stoltenborgh.neo4j.demo.datacreation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiPerson {

        public ApiPerson(){}

        private String name;
        private String surname;
        private long age;
}
