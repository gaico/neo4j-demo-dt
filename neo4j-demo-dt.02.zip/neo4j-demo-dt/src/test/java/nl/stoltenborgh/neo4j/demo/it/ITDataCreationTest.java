package nl.stoltenborgh.neo4j.demo.it;

import au.com.bytecode.opencsv.CSVReader;
import nl.stoltenborgh.neo4j.demo.NeoDemoConfig;
import nl.stoltenborgh.neo4j.demo.datacreation.ApiPerson;
import nl.stoltenborgh.neo4j.demo.datacreation.DataCreator;
import nl.stoltenborgh.neo4j.demo.domain.graph.Article;
import nl.stoltenborgh.neo4j.demo.domain.graph.ContentItem;
import nl.stoltenborgh.neo4j.demo.domain.graph.Group;
import nl.stoltenborgh.neo4j.demo.domain.graph.HasAccessTo;
import nl.stoltenborgh.neo4j.demo.domain.graph.KeyRing;
import nl.stoltenborgh.neo4j.demo.domain.graph.KeyRingKey;
import nl.stoltenborgh.neo4j.demo.domain.graph.Person;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.ArticleRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.ContentItemRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.GroupRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.GroupRepositoryCustomImpl;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.KeyRingKeyRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.KeyRingRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.PersonRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.PersonRepositoryCustomImpl;
import org.apache.commons.lang3.StringUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.web.client.RestTemplate;

import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { NeoDemoConfig.class })
public class ITDataCreationTest {

    @Autowired
    DataCreator dataCreator;

    @Autowired
    GroupRepositoryCustomImpl groupRepositoryCustom;

    @Autowired
    GroupRepository groupRepository;

    @Autowired
    ArticleRepository articleRepository;

    @Autowired
    ContentItemRepository contentItemRepository;

    @Autowired
    PersonRepository personRepository;

    @Autowired
    PersonRepositoryCustomImpl personRepositoryCustom;

    @Autowired
    KeyRingRepository keyRingRepository;

    @Autowired
    KeyRingKeyRepository keyRingKeyRepository;

    List<ApiPerson> generatedPersons;


    @Test
    public void createContentItemsAndArticles() throws IOException {
        // 13 min
        List<ContentItem> contentItems = dataCreator.createContentItems(30000, true);
        System.out.println("Created contentitems");
        List<Article> allArticles = dataCreator.createArticles(getArticles(), contentItems, 5, false);

        List<Article> articles = new ArrayList<>();
        articles.addAll(allArticles.subList(0, 3000));


        List<Article> combiArticles = new ArrayList<>();
        combiArticles.addAll(allArticles.subList(3000, allArticles.size()));

        addArticlesToCombi(combiArticles, articles, 3);

        articleRepository.saveAll(articles);
        System.out.println("Created articles");
        articleRepository.saveAll(combiArticles);
        System.out.println("Created combiArticles");

        // MATCH (p:ContentItem) RETURN COUNT(*)
        // MATCH (p:Article) RETURN COUNT(*)

        // CREATE INDEX ON :Article(ean)
    }




    @Test
    public void createPersonWithArticles() throws IOException {

        Iterable<Article> articlesTemp = articleRepository.findAll();
        List<Article> articles = new ArrayList<>();
        articlesTemp.forEach(a->articles.add(a));

        for (int i = 0; i < 150000; i++) {
//            Person newPerson = getRandomPerson();
//            personRepository.save(newPerson);

            List<Person> personList = new ArrayList<>();
            for (int j = 0; j < 4; j++) {
                personList.add(getRandomPerson());
            }
            personList.parallelStream().forEach(person->savePerson(person, articles));
        }

        /*
        MATCH (p:Person) -[]- (kr:KeyRing) -[]- (kk:KeyRingKey) RETURN p, kr, kk ORDER BY p:id skip 300000 limit 1

         MATCH(kk:KeyRingKey {value:'68d026d2-f88a-4c4c-99de-2e17fa5d046e'})
        -[]- (k:KeyRing)
        -[]- (p:Person)
        -[]- (a:Article)
        -[]- (c:ContentItem)
        RETURN kk, k, p, a, c

        MATCH(kk:KeyRingKey {value:'b88c2c70-8c5e-42e2-8fdb-d60420bcf268'})
        -[]- (k:KeyRing)
        -[]- (p:Person)
        -[]- (a:Article)
        RETURN a

        // MATCH (p:Person) RETURN COUNT(*)

        // CALL db.indexes
        // DROP INDEX ON :KeyRingKey(value)
        // CREATE INDEX ON :Person(id)

        */
    }

    private void savePerson(Person newPerson, List<Article> articles){
        personRepository.save(newPerson);
        List<Article> articlesToAdd = new ArrayList<>();
        for (int j = 0; j < 7; j++) {
            articlesToAdd.add(DataCreator.getRandomItem(articles));
        }
        personRepositoryCustom.addAccess(newPerson, articlesToAdd);
        System.out.println("Created person, one of the values in the keyRing:" + new ArrayList<KeyRingKey>(newPerson.getKeyRing().getKeyRingKeys()).get(0).getValue());
    }



    private List<Article> addArticlesToCombi(List<Article> combis, List<Article> articles, int numArticlesPerCombi) {

        for(Article combi: combis){
            for (int i = 0; i < numArticlesPerCombi; i++) {
                combi.addArticle(DataCreator.getRandomItem(articles));
            }
            combi.setContentItems(new HashSet<>());
        }
         return combis;
    }


    @Test
    public void createAllData() throws IOException {
        List<ContentItem> contentItems = dataCreator.createContentItems(1000, false);
        List<Article> articles = dataCreator.createArticles(getArticles().subList(0,100), contentItems, 5, false);
        List<Article> combiArticles = dataCreator.createCombiArticles( getArticles().subList(11,13), articles, 3, false);
        //match (ca:Article{malmbergNummer: 592095}) -[]- (a:Article) -[]- (c:ContentItem) return ca, a, c

        List<Group> schools = dataCreator.createSchools(getBoSchools().subList(1, 10), articles, 10, combiArticles, 2, false);
        //MATCH (g:Group {name: "Openbare Basisschool De Esdoorn"}) -[]- (a:Article) -[]- (c:ContentItem) return g, a, c

        List<Person> persons = dataCreator.createStudents(createRandomPersons(1), schools, articles, 7, combiArticles, 1, true);

        Optional<Person> loadedPerson = personRepository.findById(persons.get(0).getId());
        /*
        MATCH (krk:KeyRingKey {value: "fbdcb394-0d6c-44d5-9bbe-03ec5185c6be"}) -[]- (kr:KeyRing) -[]- (p:Person) -[]- (g:Group) -[]- (ag:Article) -[]- (agc:ContentItem)
        MATCH (krk:KeyRingKey {value: "fbdcb394-0d6c-44d5-9bbe-03ec5185c6be"}) -[]- (kr:KeyRing) -[]- (p:Person) -[]- (a:Article) -[]- (ac:ContentItem)
        return krk, kr, p, g, ag, a, agc, ac
        */

        articleRepository.deleteAll();
        contentItemRepository.deleteAll();
        groupRepository.deleteAll();
        personRepository.deleteAll();
        keyRingRepository.deleteAll();
        keyRingKeyRepository.deleteAll();
    }

    @Test
    public void deleteAll(){
        articleRepository.deleteAll();
        contentItemRepository.deleteAll();
        groupRepository.deleteAll();
    }

    @Test
    public void createContentItems() {
        List<ContentItem> contentItems = dataCreator.createContentItems(1000, true);
        assertEquals(getSizeOf(contentItemRepository.findAll()), contentItems.size());
        contentItemRepository.deleteAll();
        assertEquals(getSizeOf(contentItemRepository.findAll()), 0);
    }

    private int getSizeOf(Iterable iterable) {
        if(iterable instanceof List){
            return ((List) iterable).size();
        }
        throw new IllegalArgumentException(iterable.getClass().getName() + " not supported");
    }


    private List<Group> getBoSchools() throws IOException {
        List<List<String>> schoolLines = readCsv("03-alle-vestigingen-bo.csv", ';');
        List<Group> out = new ArrayList<>();
        for(List<String> line: schoolLines){
            out.add(new Group(Group.GroupType.BO, line.get(4)));
        }
        return out;
    }

    @Test
    public void testCreatePersons(){
        List<Person> people = createRandomPersons(5);
        assertEquals(5, people.size());

    }




    private List<Article> getArticles() throws IOException {
        List<List<String>> expectedItemsFile = readCsv("catalogus.2019.Schoolboekhandel.csv", ',');

        List<Article> articles = new ArrayList<>();
        for(List<String> line: expectedItemsFile){
            if(StringUtils.isNotBlank(line.get(0))){
                articles.add(new Article(line.get(0), line.get(1), line.get(2), new HashSet<>(), new HashSet<>()));
            }
        }
        return articles;
    }

    private List<List<String>> readCsv(String fileName, char seperator) throws IOException {
        String sourceDir = "./src/test/resources/data/";

        List<List<String>> records = new ArrayList<List<String>>();
        try (CSVReader csvReader = new CSVReader(new FileReader(sourceDir + fileName), seperator);) {
            String[] values = null;
            while ((values = csvReader.readNext()) != null) {
                records.add(Arrays.asList(values));
            }
        }
        return records;
    }

    public List<Person> createRandomPersons(int numberOfPersons){
        List<Person> out = new ArrayList<>(numberOfPersons);

        for(int i=0; i< numberOfPersons; i++){
            Person person = getRandomPerson();
            person.keyRing = generateKeyRingWithKeys();
            out.add(person);
        }
        return out;
    }

    private KeyRing generateKeyRingWithKeys() {
        return new KeyRing(UUID.randomUUID().toString(),
                new KeyRingKey(KeyRingKey.KeyType.REALID, UUID.randomUUID().toString()),
                new KeyRingKey(KeyRingKey.KeyType.ECKID, UUID.randomUUID().toString()));
    }

    private Person getRandomPerson(){
        if(this.generatedPersons == null || this.generatedPersons.size() < 1){
            this.generatedPersons = get500Persons();
        }
        ApiPerson apiPerson = this.generatedPersons.get(0);
        this.generatedPersons.remove(apiPerson);
        Person person = new Person(apiPerson.getName(), apiPerson.getSurname(), LocalDate.now().minusYears(apiPerson.getAge()));
        person.keyRing = generateKeyRingWithKeys();
        return person;
    }


    public List<ApiPerson> get500Persons(){
        RestTemplate restTemplate = new RestTemplate();
        ResponseEntity<List<ApiPerson>> response = restTemplate.exchange(
                "https://uinames.com/api/?region=netherlands&amount=1&amount=500&ext",
                HttpMethod.GET,
                null,
                new ParameterizedTypeReference<List<ApiPerson>>(){});
        List<ApiPerson> employees = response.getBody();
        return employees;
    }

}
