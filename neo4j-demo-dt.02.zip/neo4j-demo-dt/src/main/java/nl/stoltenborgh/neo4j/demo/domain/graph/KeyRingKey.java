package nl.stoltenborgh.neo4j.demo.domain.graph;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;

@Data
@AllArgsConstructor
@NodeEntity
public class KeyRingKey {

    @Id
    @GeneratedValue
    private Long id;

    public KeyRingKey(KeyType keyType, String value) {
        this.keyType = keyType;
        this.value = value;
    }

    public enum KeyType{
        REALID, ECKID
    }

    private KeyRingKey(){

    }

    private KeyType keyType;
    private String value;
}
