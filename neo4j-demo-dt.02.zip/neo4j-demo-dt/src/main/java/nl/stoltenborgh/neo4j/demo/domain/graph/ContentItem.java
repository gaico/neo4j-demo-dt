package nl.stoltenborgh.neo4j.demo.domain.graph;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;

@Data
@AllArgsConstructor
@NodeEntity
@EqualsAndHashCode
public class ContentItem {

    @Id
    private String id;
}
