package nl.stoltenborgh.neo4j.demo.domain.graph;

import lombok.Data;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Data
@NodeEntity
public class Person {

    @Id
    @GeneratedValue
    private Long id;

    private String firstName;
    private String lastName;
    private LocalDate dateOfBirth;

    private Person() {
        // Empty constructor required as of Neo4j API 2.0.5
    };

    public Person(String firstName, String lastName, LocalDate dateOfBirth) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.dateOfBirth = dateOfBirth;
    };

    @Relationship(type = "IS_PART_OF", direction = Relationship.UNDIRECTED)
    public Set<Group> groups = new HashSet<>();

    @Relationship(type = "HAS_ACCESS_TO", direction = Relationship.UNDIRECTED)
    public Set<Article> articles = new HashSet<>();

    @Relationship(type = "HAS_ACCESS_TO", direction = Relationship.UNDIRECTED)
    public Set<HasAccessTo> hasAccessTo = new HashSet<>();

    public void addAccessTo(Article article, HasAccessTo.Cause cause){
        this.hasAccessTo.add(new HasAccessTo(this, article, cause));
    }

    @Relationship(type = "HAS", direction = Relationship.UNDIRECTED)
    public KeyRing keyRing;

    public void addGroup(Group group) {
        this.groups.add(group);
    }

    public void addData(Group group, Set<Article> articles, Set<Article> combiArticles) {
        addGroup(group);
        this.articles.addAll(articles);
        this.articles.addAll(combiArticles);
    }
}
