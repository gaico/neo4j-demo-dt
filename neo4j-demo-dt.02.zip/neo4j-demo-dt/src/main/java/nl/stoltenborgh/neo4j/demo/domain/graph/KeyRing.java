package nl.stoltenborgh.neo4j.demo.domain.graph;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.HashSet;
import java.util.Set;

@Data
@AllArgsConstructor
@NodeEntity
public class KeyRing {

    @Id
    @GeneratedValue
    private Long id;

    private String malmbergId;

    private KeyRing(){}

    public KeyRing(String malmbergId, KeyRingKey ... keyRingKeys){
        this.malmbergId = malmbergId;
        this.keyRingKeys = new HashSet<>();
        for(KeyRingKey key: keyRingKeys){
            addKey(key);
        }
    }

    @Relationship(type = "HAS", direction = Relationship.UNDIRECTED)
    public Set<KeyRingKey> keyRingKeys;

    public void addKey(KeyRingKey key) {
        keyRingKeys.add(key);
    }
}
