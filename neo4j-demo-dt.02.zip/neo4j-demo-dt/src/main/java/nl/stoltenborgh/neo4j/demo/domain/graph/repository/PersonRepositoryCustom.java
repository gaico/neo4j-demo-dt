package nl.stoltenborgh.neo4j.demo.domain.graph.repository;

import nl.stoltenborgh.neo4j.demo.domain.graph.Article;
import nl.stoltenborgh.neo4j.demo.domain.graph.Person;

public interface PersonRepositoryCustom {
    public void addAccess(Person person, Article to);
}
