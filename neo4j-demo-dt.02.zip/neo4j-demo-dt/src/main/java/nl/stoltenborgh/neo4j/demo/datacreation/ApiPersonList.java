package nl.stoltenborgh.neo4j.demo.datacreation;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;
import sun.security.krb5.internal.APOptions;

import java.util.List;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class ApiPersonList {

        public ApiPersonList(){}

        private List<ApiPerson> apiPersons;
}
