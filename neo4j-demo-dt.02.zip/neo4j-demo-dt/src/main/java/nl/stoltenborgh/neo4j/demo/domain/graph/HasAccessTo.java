package nl.stoltenborgh.neo4j.demo.domain.graph;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.neo4j.ogm.annotation.EndNode;
import org.neo4j.ogm.annotation.RelationshipEntity;
import org.neo4j.ogm.annotation.StartNode;

@Data
@AllArgsConstructor
@RelationshipEntity(type = "HAS_ACCESS_TO")
public class HasAccessTo {

    public enum Cause {
        LICENSE, SPECIFICATION
    }

    @StartNode
    Person person;

    @EndNode
    Article article;

    Cause accesCause;


}
