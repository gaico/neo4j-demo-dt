package nl.stoltenborgh.neo4j.demo.domain.graph.repository;

import nl.stoltenborgh.neo4j.demo.domain.graph.Article;
import nl.stoltenborgh.neo4j.demo.domain.graph.HasAccessTo;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface ArticleRepository  extends Neo4jRepository<Article, Long> {





}
