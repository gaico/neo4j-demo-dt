package nl.stoltenborgh.neo4j.demo.domain.graph.repository;

import nl.stoltenborgh.neo4j.demo.domain.graph.Article;
import nl.stoltenborgh.neo4j.demo.domain.graph.Person;
import org.neo4j.ogm.model.Result;
import org.neo4j.ogm.session.Session;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.Collections;
import java.util.List;


@Repository
public class PersonRepositoryCustomImpl implements PersonRepositoryCustom  {

    @Autowired
    private SessionFactory sessionFactory;

    public void addAccess(Person person, Article to){
        String query = "MATCH (p:Person)"
                + " WHERE ID(p) = " + person.getId()
                + " MATCH (a:Article {ean: '" + to.getEan() + "'})"
                + " CREATE (p)-[r:HAS_ACCESS_TO]->(a)";
        sessionFactory.openSession().query(query, Collections.emptyMap());
    }

    @Override
    public Boolean checkAccessBy(String keyRingKeyValue, String ean) {
        String query = "MATCH(kk:KeyRingKey {value:'" + keyRingKeyValue + "'}) " +
                "-[]- (k:KeyRing) " +
                "-[]- (p:Person) " +
                "-[]- (a:Article {ean:'" + ean + "'}) " +
                "RETURN a";

        Result result = sessionFactory.openSession().query(query, Collections.emptyMap());

        if(result.queryResults().iterator().hasNext()){
            return Boolean.TRUE;
        }
        return Boolean.FALSE;
    }

    public void addAccess(Person person, List<Article> toAdd){
        String query = "MATCH (p:Person)" +
                " WHERE ID(p) = " + person.getId();

        for (int i = 0; i < toAdd.size(); i++) {
            query = query + " MATCH (a" + i + " :Article {ean: '" + toAdd.get(i).getEan() + "'})";
        }
        for (int i = 0; i < toAdd.size(); i++) {
            query = query + " CREATE (p)-[r" + i + ":HAS_ACCESS_TO]->(a" + i + ")";
        }

        sessionFactory.openSession().query(query, Collections.emptyMap());
    }
}
