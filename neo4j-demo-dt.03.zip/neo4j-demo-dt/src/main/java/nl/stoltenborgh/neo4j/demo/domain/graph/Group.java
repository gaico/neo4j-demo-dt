package nl.stoltenborgh.neo4j.demo.domain.graph;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import org.neo4j.ogm.annotation.GeneratedValue;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Queue;
import java.util.Set;

@Data
@NodeEntity
@EqualsAndHashCode
public class Group {



    public enum GroupType{
        CR("cr", 0, 0),BO("bo", 0, 12), VO("vo", 13, 18), MBO("mbo", 18, 99);

        private final String typeName;
        private final int ageFrom;
        private final int ageTo;

        GroupType(String typeName, int ageFrom, int ageTo) {
            this.typeName = typeName;
            this.ageFrom = ageFrom;
            this.ageTo = ageTo;
        }
    }

    public Group(GroupType type, String name){
        this.groupType = type;
        this.name = name;
    }

    @Id
    @GeneratedValue
    private Long id;

    @Getter
    @EqualsAndHashCode.Exclude
    private String name;

    @EqualsAndHashCode.Exclude
    @Relationship(type = "IS_PART_OF", direction = Relationship.INCOMING)
    public Set<Group> groups = new HashSet<>();

    @Getter
    @EqualsAndHashCode.Exclude
    private GroupType groupType;

    @EqualsAndHashCode.Exclude
    @Relationship(type = "HAS_ACCESS_TO", direction = Relationship.OUTGOING)
    private Set<Article> articles = new HashSet<>();


    public void addArticles(Set<Article> ... randomSet) {
        Arrays.stream(randomSet).forEach(incommingArticles -> this.articles.addAll(incommingArticles));
    }


}
