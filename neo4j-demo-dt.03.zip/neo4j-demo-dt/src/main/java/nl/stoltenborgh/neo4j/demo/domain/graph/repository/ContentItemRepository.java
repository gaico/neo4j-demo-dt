package nl.stoltenborgh.neo4j.demo.domain.graph.repository;

import nl.stoltenborgh.neo4j.demo.domain.graph.ContentItem;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface ContentItemRepository extends Neo4jRepository<ContentItem, String> {
}
