package nl.stoltenborgh.neo4j.demo.domain.graph.repository;

import nl.stoltenborgh.neo4j.demo.domain.graph.Article;
import org.springframework.data.neo4j.repository.Neo4jRepository;

public interface HasAccessToRepository extends Neo4jRepository<Article, Long> {
}
