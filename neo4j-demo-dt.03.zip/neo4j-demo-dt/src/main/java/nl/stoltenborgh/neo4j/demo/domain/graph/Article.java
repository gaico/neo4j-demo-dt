package nl.stoltenborgh.neo4j.demo.domain.graph;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import org.neo4j.ogm.annotation.Id;
import org.neo4j.ogm.annotation.NodeEntity;
import org.neo4j.ogm.annotation.Relationship;

import java.util.Set;

@Data
@NodeEntity
@AllArgsConstructor
@EqualsAndHashCode
public class Article {

    @Id
    public String malmbergNummer;
    private String ean;

    @EqualsAndHashCode.Exclude
    private String title;

    @EqualsAndHashCode.Exclude
    @Relationship(type = "HAS_ACCESS_TO", direction = Relationship.UNDIRECTED)
    Set<ContentItem> contentItems;

    @EqualsAndHashCode.Exclude
    @Relationship(type = "HAS_ACCESS_TO", direction = Relationship.UNDIRECTED)
    Set<Article> articles;

    public void addArticle(Article article){
        this.articles.add(article);
    }
}
