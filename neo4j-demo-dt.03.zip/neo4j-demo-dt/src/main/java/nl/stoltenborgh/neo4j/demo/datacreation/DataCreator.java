package nl.stoltenborgh.neo4j.demo.datacreation;

import nl.stoltenborgh.neo4j.demo.domain.graph.Article;
import nl.stoltenborgh.neo4j.demo.domain.graph.ContentItem;
import nl.stoltenborgh.neo4j.demo.domain.graph.Group;
import nl.stoltenborgh.neo4j.demo.domain.graph.KeyRing;
import nl.stoltenborgh.neo4j.demo.domain.graph.KeyRingKey;
import nl.stoltenborgh.neo4j.demo.domain.graph.Person;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.ArticleRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.ContentItemRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.GroupRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.stream.IntStream;

public class DataCreator {

//    @Autowired
//    private ArticleRepository articleRepository;

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private ContentItemRepository contentItemRepository;

    @Autowired
    private ArticleRepository articleRepository;

    public DataCreator(){

    }


    public List<ContentItem> createContentItems(int numberOfItems, boolean saveToDb) {
        List<ContentItem> out = new ArrayList<>();
        IntStream.rangeClosed(1, numberOfItems).forEach(i->out.add(new ContentItem(UUID.randomUUID().toString())));
        if (saveToDb) contentItemRepository.save(out, 1);
        return out;
    }


    public List<Article> createArticles(List<Article> articles, List<ContentItem> contentItems, int numberOfContentItemsPerArticle, boolean saveToDb) {
        articles.stream().forEach(article ->article.setContentItems(createRandomSet(contentItems, numberOfContentItemsPerArticle)));
        if (saveToDb) articleRepository.saveAll(articles);
        return articles;
    }

    public List<Article> createCombiArticles(List<Article> combiArticles, List<Article> articles,  int numberOfArticlesPerCombi, boolean saveToDb) {
        combiArticles.stream().forEach(combiArticle -> combiArticle.setArticles(createRandomSet(articles, numberOfArticlesPerCombi)));
        if (saveToDb) articleRepository.saveAll(combiArticles);
        return combiArticles;
    }

    public List<Group> createSchools(List<Group> schools, List<Article> articles, int articlesPerSchool, List<Article> combiArticles, int combiArticlesPerSchool, boolean saveToDb) {
        schools.stream().forEach(group->group.addArticles(createRandomSet(articles, articlesPerSchool), createRandomSet(combiArticles, combiArticlesPerSchool)));
        if (saveToDb) groupRepository.saveAll(schools);
        return schools;
    }

    public List<Person> createStudents(List<Person> students, List<Group> schools, List<Article> articles, int numberOfArticles, List<Article> combiArticles, int numberOfCombiArticles, boolean saveToDb) {
        students.stream().forEach(student-> student.addData(getRandomItem(schools), createRandomSet(articles, numberOfArticles), createRandomSet(combiArticles, numberOfCombiArticles)));
        if (saveToDb) personRepository.saveAll(students);
        return students;
    }

    private <T> Set<T> createRandomSet(List<T> items, int numberOfItemsPerSet) {
        Set<T> out = new HashSet<>();
        IntStream.range(0, numberOfItemsPerSet).forEach(i->out.add(getRandomItem(items)));
        return out;
    }

    public static  <T> T getRandomItem(List<T> items) {
        return items.get(new Random().nextInt(items.size()));
    }

       //    public Set<Group> createCrs(int numberOfCrs, int numberOfGroupsPerCr, Group.GroupType type) {
//        Set<Group> out = new HashSet<>();
//        for(int i=0; i<numberOfCrs; i++){
//            Group cr = new Group(Group.GroupType.CR);
//            cr.setGroupType(Group.GroupType.CR);
//            cr.setGroups(createGroups(numberOfGroupsPerCr, type));
//            groupRepository.save(cr);
//            out.add(cr);
//        }
//        return out;
//    }
//
//    private Set<Group> createGroups(int numberOfGoups, Group.GroupType type) {
//        Set<Group> out = new HashSet<>();
//        for(int i=0; i<numberOfGoups; i++){
//            Group group = new Group(type);
//            groupRepository.save(group);
//            out.add(group);
//        }
//        return out;
//    }



}
