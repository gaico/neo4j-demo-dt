package nl.stoltenborgh.neo4j.demo.domain.graph.repository;

import nl.stoltenborgh.neo4j.demo.domain.graph.Group;
import org.neo4j.ogm.session.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.Collections;

@Repository
public class GroupRepositoryCustomImpl implements GroupRepositoryCustom {

    @Autowired
    private SessionFactory sessionFactory;

    @Override
    public ArrayList<Group> findByType(Group.GroupType groupType) {
        String query = "MATCH (g:Group {groupType:'" + groupType.name() + "'})  -[r]- (sg:Group) RETURN g, r, sg";

        ArrayList<Group> out = (ArrayList) sessionFactory.openSession().query(Group.class, query, Collections.emptyMap());
        ArrayList<Group> toRemove = new ArrayList<>();
        for(Group group: out){
            if(group.getGroupType() != groupType){
                toRemove.add(group);
            }
        }
        out.removeAll(toRemove);
        return out;
    }
}
