package nl.stoltenborgh.neo4j.demo.domain.graph.repository;

import nl.stoltenborgh.neo4j.demo.domain.graph.Group;
import org.springframework.data.neo4j.repository.Neo4jRepository;
import org.springframework.stereotype.Repository;

public interface GroupRepositoryCustom {
    Iterable<Group> findByType(Group.GroupType vo);
}
