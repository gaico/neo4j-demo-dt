package nl.stoltenborgh.neo4j.demo.it;

import au.com.bytecode.opencsv.CSVReader;
import au.com.bytecode.opencsv.CSVWriter;
import nl.stoltenborgh.neo4j.demo.NeoDemoConfig;
import nl.stoltenborgh.neo4j.demo.domain.graph.HasAccessTo;
import nl.stoltenborgh.neo4j.demo.domain.graph.KeyRingKey;
import nl.stoltenborgh.neo4j.demo.domain.graph.Person;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.PersonRepository;
import nl.stoltenborgh.neo4j.demo.domain.graph.repository.PersonRepositoryCustom;
import org.junit.Test;
import org.junit.rules.Stopwatch;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import static org.junit.Assert.assertTrue;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { NeoDemoConfig.class })
public class ITSpeedTest {

    @Autowired
    private PersonRepository personRepository;

    @Autowired
    private PersonRepositoryCustom personRepositoryCustom;

    private static String CSV_DIR = "./src/test/resources/data/speedTest/";

    private class SpeedTestItem{
        private final String keyRingKeyValue;
        private final String ean;
        private long executionTime;
        private Boolean hasAccess;

        public SpeedTestItem(String keyRingKeyValue, String ean) {
            this.keyRingKeyValue = keyRingKeyValue;
            this.ean = ean;
        }

        public void setExecutionTime(long executionTime) {
            this.executionTime = executionTime;
        }

        public void setHasAccess(Boolean hasAccess) {
            this.hasAccess = hasAccess;
        }
    }

    @Test
    public void runSpeedTest(){
        SpeedTestItem item = new SpeedTestItem("d430729a-3802-4067-8ab7-fe1879c19c8a","978-94-020-1247-7");
        runSpeedTest(item);
        assertTrue(item.hasAccess);
        System.out.println("ExecutionTime: " + item.executionTime);
    }


    @Test
    public void runSpeedTestFromSavedTestSets() {
        List<SpeedTestItem> testData = new ArrayList<>();

        for(String testFileName: getAllTestFileNames()){
            List<List<String>> testDataTmp = readCsv(testFileName, ',');
            for(List<String> testDataTmpLine: testDataTmp){
                testData.add(new SpeedTestItem(testDataTmpLine.get(0), testDataTmpLine.get(1)));
            }
        }
        runSpeedTest(testData);

        int counter = 0;
        long totalExecutionTime = 0;
        for(SpeedTestItem item: testData) {
            totalExecutionTime = totalExecutionTime + item.executionTime;
            System.out.println("Item " + ++counter + ": " + item.executionTime);
        }
        long averageExecutionTime = totalExecutionTime / testData.size();

        System.out.println("Total executiontime: " + totalExecutionTime);
        System.out.println("Total number of executions: " + testData.size());
        System.out.println("Average: " + averageExecutionTime);
    }

    private void runSpeedTest(List<SpeedTestItem> testData) {
        testData.stream().forEach(testDataItem->runSpeedTest(testDataItem));
    }

    private void runSpeedTest(SpeedTestItem testDataItem) {
        long startTime = System.currentTimeMillis();
    
        Boolean hasAccess = personRepositoryCustom.checkAccessBy(testDataItem.keyRingKeyValue, testDataItem.ean);
    
        long stopTime = System.currentTimeMillis();
        testDataItem.setExecutionTime(stopTime - startTime);
        testDataItem.setHasAccess(hasAccess);
    }

    private List<String> getAllTestFileNames() {
        List<String> result = new ArrayList<>();
        try (Stream<Path> walk = Files.walk(Paths.get(CSV_DIR))) {
            result =  walk.map(x -> x.toString()).filter(f -> f.endsWith(".csv")).collect(Collectors.toList());
        } catch (IOException e) {
            e.printStackTrace();
        }
        return result;
    }

    private List<List<String>> readCsv(String fileName, char seperator) {
        List<List<String>> records = new ArrayList<List<String>>();
        try (CSVReader csvReader = new CSVReader(new FileReader(fileName), seperator);) {
            String[] values = null;
            while ((values = csvReader.readNext()) != null) {
                records.add(Arrays.asList(values));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return records;
    }

    @Test
    public void createTestSets() throws IOException {
        createTestSet(10, 1000, "10th1000.csv");
        createTestSet(100, 1000, "100th1000.csv");
        createTestSet(500, 1000, "500th1000.csv");
        createTestSet(1000, 1000, "1000th1000.csv");
    }

    private void createTestSet(int page, int size, String filename) throws IOException {
        List<Person> testPersons = new ArrayList<>();
        Pageable pageable = PageRequest.of(page, size, Sort.by("id").descending());
        Page<Person> persons = personRepository.findAll(pageable, 2);
        persons.get().forEach(person -> testPersons.add(person));
        writeToCsv(testPersons, filename);
    }

    private void writeToCsv(List<Person> testPersons, String filename) throws IOException {
        CSVWriter writer = new CSVWriter(new FileWriter(CSV_DIR + filename));
        for (Person person : testPersons) {
            HasAccessTo[] hasAccessTos = new HasAccessTo[person.getHasAccessTo().size()];
            HasAccessTo[] accessArray = person.getHasAccessTo().toArray(hasAccessTos);

            KeyRingKey[] keyRingKeys = new KeyRingKey[person.getKeyRing().getKeyRingKeys().size()];
            KeyRingKey[] keyRingKeysArray = person.getKeyRing().getKeyRingKeys().toArray(keyRingKeys);

            if(accessArray[0].getArticle().getEan().length() > 3) {
                writer.writeNext(new String[]{keyRingKeysArray[0].getValue(), accessArray[0].getArticle().getEan()});
            };
        }
        writer.close();
    }

}
